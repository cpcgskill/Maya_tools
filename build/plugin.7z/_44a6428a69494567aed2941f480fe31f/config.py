
import sys
import _44a6428a69494567aed2941f480fe31f
_44a6428a69494567aed2941f480fe31f.config = sys.modules.get(__name__)
u'\n:\u521b\u5efa\u65f6\u95f4: 2020/12/30 20:32\n:\u4f5c\u8005: \u82cd\u4e4b\u5e7b\u7075\n:\u6211\u7684\u4e3b\u9875: https://cpcgskill.com\n:QQ: 2921251087\n:\u7231\u53d1\u7535: https://afdian.net/@Phantom_of_the_Cang\n:aboutcg: https://www.aboutcg.org/teacher/54335\n:bilibili: https://space.bilibili.com/351598127\n\n'
import os
PATH = os.path.dirname(os.path.abspath(__file__)).replace(u'\\', u'/')
DEBUG = True
Title = u'Tools'
START_TIME = u'2020'
Version = 0.1
ASSETS = (PATH + u'/assets')
IMAGES = (PATH + u'/assets/images')
HEAD_IMG = (PATH + u'/assets/images/head.png')
del os
